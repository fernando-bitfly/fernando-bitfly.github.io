﻿namespace LafargeCTECMahltestAuswertung
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbxInputRPMThreshold = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnStartEvaluation = new System.Windows.Forms.Button();
            this.tbxInputMillRevs = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbxInputGrindingMass = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxInputSampleID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxInputUAT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSelectRawFile = new System.Windows.Forms.Button();
            this.tbxInputRawData = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbxOutputPower = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbxOutputGrindingTime = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tbxOutputSpecificEnergyConsumption = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbxOutputEnergyConsumption = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbxOutputTorgue = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbxOutputMillRevsReal = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnExportResults = new System.Windows.Forms.Button();
            this.tbxOutputMillRevsTarget = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbxOutputGrindingMass = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbxOutputSampleID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxOutputUAT = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbxOutputMeasurementDate = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ofdInputFile = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.tbxInputRPMThreshold);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.btnStartEvaluation);
            this.groupBox1.Controls.Add(this.tbxInputMillRevs);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbxInputGrindingMass);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbxInputSampleID);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbxInputUAT);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnSelectRawFile);
            this.groupBox1.Controls.Add(this.tbxInputRawData);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(882, 208);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rohdaten";
            // 
            // tbxInputRPMThreshold
            // 
            this.tbxInputRPMThreshold.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxInputRPMThreshold.Location = new System.Drawing.Point(122, 152);
            this.tbxInputRPMThreshold.Name = "tbxInputRPMThreshold";
            this.tbxInputRPMThreshold.Size = new System.Drawing.Size(716, 20);
            this.tbxInputRPMThreshold.TabIndex = 13;
            this.tbxInputRPMThreshold.Text = "20";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(45, 155);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "RPM Grenze:";
            // 
            // btnStartEvaluation
            // 
            this.btnStartEvaluation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStartEvaluation.Location = new System.Drawing.Point(725, 179);
            this.btnStartEvaluation.Name = "btnStartEvaluation";
            this.btnStartEvaluation.Size = new System.Drawing.Size(151, 23);
            this.btnStartEvaluation.TabIndex = 11;
            this.btnStartEvaluation.Text = "Auswertung starten";
            this.btnStartEvaluation.UseVisualStyleBackColor = true;
            this.btnStartEvaluation.Click += new System.EventHandler(this.btnStartEvaluation_Click);
            // 
            // tbxInputMillRevs
            // 
            this.tbxInputMillRevs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxInputMillRevs.Location = new System.Drawing.Point(122, 126);
            this.tbxInputMillRevs.Name = "tbxInputMillRevs";
            this.tbxInputMillRevs.Size = new System.Drawing.Size(716, 20);
            this.tbxInputMillRevs.TabIndex = 10;
            this.tbxInputMillRevs.Text = "200";
            this.tbxInputMillRevs.TextChanged += new System.EventHandler(this.tbxInputMillRevs_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Mühlenumdrehungen:";
            // 
            // tbxInputGrindingMass
            // 
            this.tbxInputGrindingMass.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxInputGrindingMass.Location = new System.Drawing.Point(122, 100);
            this.tbxInputGrindingMass.Name = "tbxInputGrindingMass";
            this.tbxInputGrindingMass.Size = new System.Drawing.Size(716, 20);
            this.tbxInputGrindingMass.TabIndex = 8;
            this.tbxInputGrindingMass.Text = "10";
            this.tbxInputGrindingMass.TextChanged += new System.EventHandler(this.tbxInputGrindingMass_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Mahlgut [kg]:";
            // 
            // tbxInputSampleID
            // 
            this.tbxInputSampleID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxInputSampleID.Location = new System.Drawing.Point(122, 74);
            this.tbxInputSampleID.Name = "tbxInputSampleID";
            this.tbxInputSampleID.Size = new System.Drawing.Size(716, 20);
            this.tbxInputSampleID.TabIndex = 6;
            this.tbxInputSampleID.TextChanged += new System.EventHandler(this.tbxInputSampleID_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Proben ID:";
            // 
            // tbxInputUAT
            // 
            this.tbxInputUAT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxInputUAT.Location = new System.Drawing.Point(122, 48);
            this.tbxInputUAT.Name = "tbxInputUAT";
            this.tbxInputUAT.Size = new System.Drawing.Size(716, 20);
            this.tbxInputUAT.TabIndex = 4;
            this.tbxInputUAT.TextChanged += new System.EventHandler(this.tbxInputUAT_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "UAT:";
            // 
            // btnSelectRawFile
            // 
            this.btnSelectRawFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectRawFile.Location = new System.Drawing.Point(844, 20);
            this.btnSelectRawFile.Name = "btnSelectRawFile";
            this.btnSelectRawFile.Size = new System.Drawing.Size(32, 23);
            this.btnSelectRawFile.TabIndex = 2;
            this.btnSelectRawFile.Text = "...";
            this.btnSelectRawFile.UseVisualStyleBackColor = true;
            this.btnSelectRawFile.Click += new System.EventHandler(this.btnSelectRawFile_Click);
            // 
            // tbxInputRawData
            // 
            this.tbxInputRawData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxInputRawData.Enabled = false;
            this.tbxInputRawData.Location = new System.Drawing.Point(122, 22);
            this.tbxInputRawData.Name = "tbxInputRawData";
            this.tbxInputRawData.ReadOnly = true;
            this.tbxInputRawData.Size = new System.Drawing.Size(716, 20);
            this.tbxInputRawData.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pfad zu Rohdaten:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.tbxOutputPower);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.tbxOutputGrindingTime);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.tbxOutputSpecificEnergyConsumption);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.tbxOutputEnergyConsumption);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.tbxOutputTorgue);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.tbxOutputMillRevsReal);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.btnExportResults);
            this.groupBox2.Controls.Add(this.tbxOutputMillRevsTarget);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tbxOutputGrindingMass);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.tbxOutputSampleID);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.tbxOutputUAT);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.tbxOutputMeasurementDate);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(12, 254);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(882, 358);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ergebnisse";
            // 
            // tbxOutputPower
            // 
            this.tbxOutputPower.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputPower.Enabled = false;
            this.tbxOutputPower.Location = new System.Drawing.Point(153, 229);
            this.tbxOutputPower.Name = "tbxOutputPower";
            this.tbxOutputPower.ReadOnly = true;
            this.tbxOutputPower.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputPower.TabIndex = 23;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(54, 232);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(93, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "Leistung MW [W]:";
            // 
            // tbxOutputGrindingTime
            // 
            this.tbxOutputGrindingTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputGrindingTime.Enabled = false;
            this.tbxOutputGrindingTime.Location = new System.Drawing.Point(153, 126);
            this.tbxOutputGrindingTime.Name = "tbxOutputGrindingTime";
            this.tbxOutputGrindingTime.ReadOnly = true;
            this.tbxOutputGrindingTime.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputGrindingTime.TabIndex = 21;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(73, 129);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 13);
            this.label16.TabIndex = 20;
            this.label16.Text = "Mahldauer [s]:";
            // 
            // tbxOutputSpecificEnergyConsumption
            // 
            this.tbxOutputSpecificEnergyConsumption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputSpecificEnergyConsumption.Enabled = false;
            this.tbxOutputSpecificEnergyConsumption.Location = new System.Drawing.Point(153, 286);
            this.tbxOutputSpecificEnergyConsumption.Name = "tbxOutputSpecificEnergyConsumption";
            this.tbxOutputSpecificEnergyConsumption.ReadOnly = true;
            this.tbxOutputSpecificEnergyConsumption.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputSpecificEnergyConsumption.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 289);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(141, 13);
            this.label14.TabIndex = 18;
            this.label14.Text = "Spez. Mahlenergie [kWh/h]:";
            // 
            // tbxOutputEnergyConsumption
            // 
            this.tbxOutputEnergyConsumption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputEnergyConsumption.Enabled = false;
            this.tbxOutputEnergyConsumption.Location = new System.Drawing.Point(153, 260);
            this.tbxOutputEnergyConsumption.Name = "tbxOutputEnergyConsumption";
            this.tbxOutputEnergyConsumption.ReadOnly = true;
            this.tbxOutputEnergyConsumption.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputEnergyConsumption.TabIndex = 17;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(21, 263);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(126, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Energieverbrauch [kWh]:";
            // 
            // tbxOutputTorgue
            // 
            this.tbxOutputTorgue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputTorgue.Enabled = false;
            this.tbxOutputTorgue.Location = new System.Drawing.Point(153, 203);
            this.tbxOutputTorgue.Name = "tbxOutputTorgue";
            this.tbxOutputTorgue.ReadOnly = true;
            this.tbxOutputTorgue.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputTorgue.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(29, 206);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Drehmoment MW [Nm]:";
            // 
            // tbxOutputMillRevsReal
            // 
            this.tbxOutputMillRevsReal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputMillRevsReal.Enabled = false;
            this.tbxOutputMillRevsReal.Location = new System.Drawing.Point(153, 177);
            this.tbxOutputMillRevsReal.Name = "tbxOutputMillRevsReal";
            this.tbxOutputMillRevsReal.ReadOnly = true;
            this.tbxOutputMillRevsReal.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputMillRevsReal.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(56, 180);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Umdrehungen Ist:";
            // 
            // btnExportResults
            // 
            this.btnExportResults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportResults.Enabled = false;
            this.btnExportResults.Location = new System.Drawing.Point(725, 329);
            this.btnExportResults.Name = "btnExportResults";
            this.btnExportResults.Size = new System.Drawing.Size(151, 23);
            this.btnExportResults.TabIndex = 11;
            this.btnExportResults.Text = "Ergebnisse exportieren";
            this.btnExportResults.UseVisualStyleBackColor = true;
            this.btnExportResults.Click += new System.EventHandler(this.btnExportResults_Click);
            // 
            // tbxOutputMillRevsTarget
            // 
            this.tbxOutputMillRevsTarget.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputMillRevsTarget.Enabled = false;
            this.tbxOutputMillRevsTarget.Location = new System.Drawing.Point(153, 151);
            this.tbxOutputMillRevsTarget.Name = "tbxOutputMillRevsTarget";
            this.tbxOutputMillRevsTarget.ReadOnly = true;
            this.tbxOutputMillRevsTarget.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputMillRevsTarget.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(50, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Umdrehungen Soll:";
            // 
            // tbxOutputGrindingMass
            // 
            this.tbxOutputGrindingMass.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputGrindingMass.Enabled = false;
            this.tbxOutputGrindingMass.Location = new System.Drawing.Point(153, 100);
            this.tbxOutputGrindingMass.Name = "tbxOutputGrindingMass";
            this.tbxOutputGrindingMass.ReadOnly = true;
            this.tbxOutputGrindingMass.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputGrindingMass.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(78, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Mahlgut [kg]:";
            // 
            // tbxOutputSampleID
            // 
            this.tbxOutputSampleID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputSampleID.Enabled = false;
            this.tbxOutputSampleID.Location = new System.Drawing.Point(153, 74);
            this.tbxOutputSampleID.Name = "tbxOutputSampleID";
            this.tbxOutputSampleID.ReadOnly = true;
            this.tbxOutputSampleID.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputSampleID.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(89, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Proben ID:";
            // 
            // tbxOutputUAT
            // 
            this.tbxOutputUAT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputUAT.Enabled = false;
            this.tbxOutputUAT.Location = new System.Drawing.Point(153, 48);
            this.tbxOutputUAT.Name = "tbxOutputUAT";
            this.tbxOutputUAT.ReadOnly = true;
            this.tbxOutputUAT.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputUAT.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(115, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "UAT:";
            // 
            // tbxOutputMeasurementDate
            // 
            this.tbxOutputMeasurementDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputMeasurementDate.Enabled = false;
            this.tbxOutputMeasurementDate.Location = new System.Drawing.Point(153, 22);
            this.tbxOutputMeasurementDate.Name = "tbxOutputMeasurementDate";
            this.tbxOutputMeasurementDate.ReadOnly = true;
            this.tbxOutputMeasurementDate.Size = new System.Drawing.Size(723, 20);
            this.tbxOutputMeasurementDate.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(61, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Ausgewertet am:";
            // 
            // ofdInputFile
            // 
            this.ofdInputFile.FileName = "mdf Datei";
            this.ofdInputFile.Filter = "MDF Dateien|*.mdf|Alle Dateien|*.*";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 624);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Lafarge CTEC Mahltest Auswertung";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnStartEvaluation;
        private System.Windows.Forms.TextBox tbxInputMillRevs;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbxInputGrindingMass;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxInputSampleID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxInputUAT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSelectRawFile;
        private System.Windows.Forms.TextBox tbxInputRawData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbxOutputSpecificEnergyConsumption;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbxOutputEnergyConsumption;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbxOutputTorgue;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbxOutputMillRevsReal;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnExportResults;
        private System.Windows.Forms.TextBox tbxOutputMillRevsTarget;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbxOutputGrindingMass;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbxOutputSampleID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbxOutputUAT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbxOutputMeasurementDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.OpenFileDialog ofdInputFile;
        private System.Windows.Forms.TextBox tbxInputRPMThreshold;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbxOutputGrindingTime;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbxOutputPower;
        private System.Windows.Forms.Label label17;
    }
}

