﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LafargeCTECMahltestAuswertung
{
    public class Reading
    {
        public double Time { get; set; }
        public double Power { get; set; }
        public double Speed { get; set; }
        public double Torque { get; set; }
    }
}
