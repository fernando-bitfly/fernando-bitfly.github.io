﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LafargeCTECMahltestAuswertung
{
    public partial class MainForm : Form
    {
        private CultureInfo _CI = new CultureInfo("en-US");

        public MainForm()
        {
            InitializeComponent();
        }

        private void tbxInputUAT_TextChanged(object sender, EventArgs e)
        {
            tbxOutputUAT.Text = tbxInputUAT.Text;
        }

        private void btnStartEvaluation_Click(object sender, EventArgs e)
        {
            if (!File.Exists(tbxInputRawData.Text))
            {
                MessageBox.Show("Kein Rohdatenfile ausgewählt oder ausgewähltes Rohdatenfile existiert nicht.", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (tbxInputUAT.Text.Length < 5)
            {
                MessageBox.Show("Kein oder ungültiger UAT eingegeben.", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (tbxInputSampleID.Text.Length < 8)
            {
                MessageBox.Show("Keine oder ungültige Probenkennung eingegeben.", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double grindingMass;

            if (!double.TryParse(tbxInputGrindingMass.Text, out grindingMass))
            {
                MessageBox.Show("Keine oder ungültige Mahlgutmenge eingegeben.", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double millsRevTarget;

            if (!double.TryParse(tbxInputMillRevs.Text, out millsRevTarget))
            {
                MessageBox.Show("Keine oder ungültige Mühlenumdrehungen eingegeben.", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double rpmCutoff;
            if (!double.TryParse(tbxInputRPMThreshold.Text, out rpmCutoff))
            {
                MessageBox.Show("Keine oder ungültige RPM Grenze eingegeben.", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            tbxOutputMeasurementDate.Text = DateTime.Now.ToString();

            var data = File.ReadAllLines(tbxInputRawData.Text);

            var readings = new List<Reading>();

            for (var i = 1; i < data.Length; i++)
            {
                var currLine = data[i];
                //var prevLine = data[i - 1];
                if (currLine.StartsWith("Speed") || string.IsNullOrWhiteSpace(currLine))
                    continue;

                var lineSplit = currLine.Split('\t');
                double speed, torque, power, time;

                if (!double.TryParse(lineSplit[0], NumberStyles.Any, _CI, out speed))
                {
                    MessageBox.Show(lineSplit[0] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!double.TryParse(lineSplit[1], NumberStyles.Any, _CI, out torque))
                {
                    MessageBox.Show(lineSplit[1] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!double.TryParse(lineSplit[2], NumberStyles.Any, _CI, out power))
                {
                    MessageBox.Show(lineSplit[2] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!double.TryParse(lineSplit[3], NumberStyles.Any, _CI, out time))
                {
                    MessageBox.Show(lineSplit[3] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (speed >= rpmCutoff)
                {
                    readings.Add(new Reading() { Power = power, Speed = speed, Torque = torque, Time = time });
                }
                


                //lineSplit = prevLine.Split('\t');
                //double prevSpeed, prevTorque, prevPower, prevTime;

                //if (!double.TryParse(lineSplit[0], NumberStyles.Any, _CI, out prevSpeed))
                //{
                //    MessageBox.Show(lineSplit[0] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return;
                //}

                //if (!double.TryParse(lineSplit[1], NumberStyles.Any, _CI, out prevTorque))
                //{
                //    MessageBox.Show(lineSplit[1] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return;
                //}

                //if (!double.TryParse(lineSplit[2], NumberStyles.Any, _CI, out prevPower))
                //{
                //    MessageBox.Show(lineSplit[2] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return;
                //}

                //if (!double.TryParse(lineSplit[3], NumberStyles.Any, _CI, out prevTime))
                //{
                //    MessageBox.Show(lineSplit[3] + " ist keine gültiger Wert für 'Speed'", "Eingabefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return;
                //}

                //if (speed == 0)
                //    continue;

                //realRev += speed / 60.0;
            }

            var testDuration = readings.Max(r => r.Time) - readings.Min(r => r.Time);
            var readingInterval = testDuration / readings.Count;

            var realRev = readings.Sum(r => r.Speed) / (readingInterval * 60);

            var avgTorque = readings.Average(r => r.Torque);
            var avgPower = readings.Sum(r => r.Power) / (testDuration);

            var energyConsumption = avgPower / 3600 * testDuration / 1000;
            var specificEnergyConsumption = energyConsumption / 10 * 1000;
            tbxOutputGrindingTime.Text = Math.Round(testDuration, 1).ToString();
            tbxOutputTorgue.Text = Math.Round(avgTorque, 1).ToString();
            tbxOutputPower.Text = Math.Round(avgPower, 1).ToString();
            tbxOutputEnergyConsumption.Text = Math.Round(energyConsumption, 8).ToString();
            tbxOutputSpecificEnergyConsumption.Text = Math.Round(specificEnergyConsumption, 3).ToString();
            tbxOutputMillRevsReal.Text = Math.Round(realRev, 0).ToString();
            tbxOutputSampleID.Text = tbxInputSampleID.Text;
            tbxOutputUAT.Text = tbxInputUAT.Text;
            tbxOutputGrindingMass.Text = tbxInputGrindingMass.Text;
            tbxOutputMillRevsTarget.Text = tbxInputMillRevs.Text;

            btnExportResults.Enabled = true;
        }

        private void tbxInputSampleID_TextChanged(object sender, EventArgs e)
        {
            tbxOutputSampleID.Text = tbxInputSampleID.Text;
        }

        private void tbxInputGrindingMass_TextChanged(object sender, EventArgs e)
        {
            tbxOutputGrindingMass.Text = tbxInputGrindingMass.Text;
        }

        private void tbxInputMillRevs_TextChanged(object sender, EventArgs e)
        {
            tbxOutputMillRevsTarget.Text = tbxInputMillRevs.Text;
        }

        private void btnSelectRawFile_Click(object sender, EventArgs e)
        {
            if (ofdInputFile.ShowDialog() == DialogResult.OK)
            {
                tbxInputRawData.Text = ofdInputFile.FileName;
            }
        }

        private void btnExportResults_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(tbxOutputMeasurementDate.Text + '\t' + 
                tbxOutputUAT.Text + '\t' +
                tbxInputSampleID.Text + '\t' +
                tbxOutputGrindingMass.Text + '\t' +
                tbxOutputGrindingTime.Text + '\t' +
                tbxOutputMillRevsTarget.Text + '\t' +
                tbxOutputMillRevsReal.Text + '\t' +
                tbxOutputTorgue.Text + '\t' +
                tbxOutputPower.Text + '\t' +
                tbxOutputEnergyConsumption.Text + '\t' +
                tbxOutputSpecificEnergyConsumption.Text + '\t');

            MessageBox.Show("Das Ergebniss wurde in die Zwischenablage kopiert.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
